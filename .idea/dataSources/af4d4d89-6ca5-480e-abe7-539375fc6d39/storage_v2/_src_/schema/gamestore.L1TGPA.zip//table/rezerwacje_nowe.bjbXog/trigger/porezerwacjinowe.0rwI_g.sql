create trigger poRezerwacjiNowe
  before INSERT
  on rezerwacje_nowe
  for each row
  BEGIN
	
        
        UPDATE Magazyn M
        SET stan_magazynu = stan_magazynu - 1
        WHERE M.id_gp = NEW.id_gp;
    
END;

