create trigger poTransakcjiNowe
  before INSERT
  on transakcje_nowe
  for each row
  BEGIN
	DECLARE ostatniBudzet INT DEFAULT 0;
    
    SELECT koncowa_wartosc
			 FROM Budzet ORDER BY data_zmiany DESC 
			LIMIT 1
			INTO ostatniBudzet;
            
	IF NEW.rodzaj="kupno"
    THEN
		INSERT INTO Budzet VALUES(
			"kupno",
			curdate(),
			nowyBudzet - NEW.suma
		);
        
		UPDATE Magazyn M
        SET stan_magazynu = stan_magazynu + liczba
        WHERE M.id_gp = NEW.id_gp;
		
	ELSE
		INSERT INTO Budzet VALUES(
			"sprzedaz",
			curdate(),
			nowyBudzet + NEW.suma
		);
        
        
        UPDATE Magazyn M
        SET stan_magazynu = stan_magazynu - liczba
        WHERE M.id_gp = NEW.id_gp;
    
    END IF;
END;

