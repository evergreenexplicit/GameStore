create trigger poRezerwacjiUzywane
  before INSERT
  on rezerwacje_uzywane
  for each row
  BEGIN
	
        
        UPDATE Uzywane_gry
        SET dostepnosc = "zarezerwowana"
        WHERE id = NEW.id_uzywane;
    
END;

