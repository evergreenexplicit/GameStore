create trigger poTransakcjiUzywane
  before INSERT
  on transakcje_uzywane
  for each row
  BEGIN
	DECLARE ostatniBudzet INT DEFAULT 0;
    
    SELECT koncowa_wartosc
			 FROM Budzet ORDER BY data_zmiany DESC 
			LIMIT 1
			INTO ostatniBudzet;
	IF NEW.rodzaj="kupno"
    THEN
		INSERT INTO Budzet VALUES(
			"kupno",
			curdate(),
			nowyBudzet - NEW.suma
		);
		
		
	ELSE
		INSERT INTO Budzet VALUES(
			"sprzedaz",
			curdate(),
			nowyBudzet + NEW.suma
		);
        
        
        UPDATE Uzywane_gry SET dostepnosc ="sprzedana" WHERE id = NEW.id_uzywanej; /*TODO zamienic na tylko zmaine doespnosci*/
    
    END IF;
END;

